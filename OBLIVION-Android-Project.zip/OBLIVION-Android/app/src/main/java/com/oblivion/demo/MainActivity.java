package com.oblivion.demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final int bg = Color.rgb(12, 20, 29), panel = Color.rgb(26, 38, 50), fg = Color.rgb(235, 241, 246), muted = Color.rgb(155, 171, 185), cyan = Color.rgb(80, 220, 230);
    LinearLayout root;
    int page = 0;
    EditText phoneField;
    TextView result;

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER); l.setPadding(24, 22, 24, 22); return l;
    }
    TextView button(String s, Runnable r) {
        TextView b = text(s, 15, Color.rgb(8, 22, 29), true); b.setBackground(shape(cyan, 12));
        b.setPadding(24, 15, 24, 15); b.setOnClickListener(v -> r.run()); return b;
    }
    void base() { root = column(); root.setBackgroundColor(bg); setContentView(root); }
    @Override public void onCreate(Bundle b) { super.onCreate(b); showWelcome(); }

    void showWelcome() {
        page = 0; base();
        root.setBackgroundResource(R.drawable.oblivion_background);
        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView note = text("WHATSAPP NUMBER STATUS • DEMO", 11, Color.WHITE, true);
        note.setBackground(shape(0xCC101D27, 18)); note.setPadding(16, 10, 16, 10); root.addView(note);
        TextView next = button("MULAI CEK", this::showChecker);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = 16; root.addView(next, bp);
    }

    void showChecker() {
        page = 1; base();
        TextView title = text("OBLIVION", 27, cyan, true); title.setLetterSpacing(.08f); root.addView(title);
        TextView subtitle = text("WHATSAPP STATUS CHECKER", 12, muted, true); root.addView(subtitle);
        TextView label = text("Nomor WhatsApp (pakai kode negara)", 14, fg, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = 30; root.addView(label, lp);
        phoneField = new EditText(this); phoneField.setSingleLine(true); phoneField.setInputType(3); phoneField.setTextColor(fg); phoneField.setHintTextColor(muted); phoneField.setHint("Contoh: 6281234567890"); phoneField.setBackground(shape(panel, 12)); phoneField.setPadding(16, 13, 16, 13);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = 10; root.addView(phoneField, fp);
        TextView check = button("CHECK NUMBER", this::checkNumber); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = 16; root.addView(check, cp);
        result = text("STATUS: BELUM DIPERIKSA", 16, muted, true); result.setBackground(shape(panel, 12)); result.setPadding(12, 18, 12, 18);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.topMargin = 22; root.addView(result, rp);
        TextView legend = text("ACTIVE  •  BANNED  •  UNKNOWN", 12, cyan, true); LinearLayout.LayoutParams lg = new LinearLayout.LayoutParams(-1, -2); lg.topMargin = 20; root.addView(legend, lg);
        TextView disclaimer = text("Catatan: WhatsApp tidak menyediakan akses publik untuk memastikan status banned nomor orang lain. Hasil otomatis akan ditandai UNKNOWN, bukan menebak status.", 12, muted, false);
        disclaimer.setPadding(6, 14, 6, 8); root.addView(disclaimer);
        TextView back = text("‹ Kembali", 14, fg, false); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = 8; root.addView(back, bp); back.setOnClickListener(v -> showWelcome());
    }

    void checkNumber() {
        String number = phoneField.getText().toString().trim().replace("+", "").replace(" ", "").replace("-", "");
        if (!number.matches("[0-9]{8,15}")) {
            result.setText("NOMOR TIDAK VALID\nMasukkan 8–15 digit, termasuk kode negara.");
            result.setTextColor(Color.rgb(255, 190, 90));
            return;
        }
        result.setText("STATUS: UNKNOWN\nNomor tercatat untuk pemeriksaan tampilan, tetapi status banned tidak dapat diverifikasi dari aplikasi ini.");
        result.setTextColor(Color.rgb(255, 205, 100));
    }

    @Override public void onBackPressed() { if (page == 1) showWelcome(); else super.onBackPressed(); }
}
