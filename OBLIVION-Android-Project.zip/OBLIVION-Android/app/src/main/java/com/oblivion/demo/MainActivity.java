package com.oblivion.demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final int bg = Color.rgb(16,29,39), fg = Color.rgb(224,229,234), muted = Color.rgb(151,163,174);
    LinearLayout root;
    int page = 0;
    EditText demoField;

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER); l.setPadding(26,24,26,24); return l;
    }
    TextView button(String s, Runnable r) {
        TextView b=text(s,15,Color.rgb(22,29,35),true); b.setBackground(shape(fg,8));
        b.setPadding(30,14,30,14); b.setOnClickListener(v -> r.run()); return b;
    }
    void base() {
        root=column(); root.setBackgroundColor(bg); setContentView(root);
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); showWelcome(); }
    void showWelcome() {
        page=0; base();
        root.setBackgroundResource(R.drawable.oblivion_background);
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView note=text("DEMO LOKAL • Tidak mengirim data",11,Color.rgb(75,75,75),true);
        note.setBackground(shape(0xCCFFFFFF,18));
        note.setPadding(16,8,16,8);
        root.addView(note);
        TextView next=button("NEXT",()->showDemo());
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);
        bp.topMargin=16; root.addView(next,bp);
    }
    void showDemo() {
        page=1; base();
        TextView back=text("‹",32,fg,false); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); back.setOnClickListener(v->showWelcome()); root.addView(back);
        TextView title=text("OBLIVION",25,fg,true); title.setLetterSpacing(.08f); root.addView(title);
        TextView desc=text("Demo halaman input",14,muted,false); root.addView(desc);
        TextView art=text("✦\n\n◇   ✧   ◇\n\n✧   ◉   ✧",34,muted,false);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,0,1); root.addView(art,ap);
        TextView label=text("Contoh teks lokal (opsional)",13,fg,false); root.addView(label);
        demoField=new EditText(this); demoField.setSingleLine(true); demoField.setTextColor(fg); demoField.setHintTextColor(muted); demoField.setHint("Teks demo"); demoField.setBackground(shape(Color.rgb(31,45,56),10)); demoField.setPadding(16,12,16,12);
        root.addView(demoField,new LinearLayout.LayoutParams(-1,-2));
        TextView info=text("Input hanya ditampilkan di perangkat dan tidak disimpan atau dikirim.",11,muted,false);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=12; root.addView(info,ip);
        TextView next=button("NEXT",()->showDone()); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=22; root.addView(next,bp);
    }
    void showDone() {
        page=2; base();
        TextView icon=text("✓",58,fg,true); root.addView(icon);
        TextView title=text("Demo selesai",25,fg,true); root.addView(title);
        TextView desc=text("Navigasi berhasil. Tidak ada data yang dikirim.",14,muted,false);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2); dp.topMargin=12; root.addView(desc,dp);
        TextView again=button("KEMBALI KE AWAL",()->showWelcome()); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=30; root.addView(again,bp);
    }
    @Override public void onBackPressed() { if(page==2) showDemo(); else if(page==1) showWelcome(); else super.onBackPressed(); }
}
