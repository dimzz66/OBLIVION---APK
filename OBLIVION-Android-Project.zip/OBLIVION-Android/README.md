# OBLIVION Android demo

A local UI demo for entering a WhatsApp number and displaying an honest UNKNOWN result. WhatsApp does not provide a public third-party endpoint for confirming another person's ban status, so this app does not claim ACTIVE/BANNED without official verification.

## Build
Open this Android Gradle project in Android Studio (JDK 17, Android SDK 35) and build `app` with `assembleDebug`.

No network permission is declared; the entered number is not transmitted or stored.
