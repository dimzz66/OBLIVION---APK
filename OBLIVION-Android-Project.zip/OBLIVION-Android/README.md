# OBLIVION Android demo

Proyek Android Studio sederhana (Java, tanpa izin jaringan) untuk demo tampilan dan navigasi lokal.

## Membuka dan membangun
1. Ekstrak ZIP.
2. Buka folder `OBLIVION-Android` di Android Studio.
3. Gunakan JDK 17 dan Android SDK 35; izinkan Gradle melakukan sinkronisasi.
4. Pilih **Build > Build APK(s)**. APK debug akan berada di `app/build/outputs/apk/debug/`.

## Mengganti identitas
- Nama aplikasi: ubah `android:label` di `app/src/main/AndroidManifest.xml`.
- Ikon: ganti `app/src/main/res/drawable/ic_oblivion.xml` dengan ikon vector milikmu (atau ubah referensi manifest ke mipmap ikon PNG).
- Background: ubah warna `bg` di `MainActivity.java` atau ganti bagian ilustrasi teks dengan aset latar milikmu.
- Paket aplikasi: ubah `namespace` dan `applicationId` pada `app/build.gradle`, serta deklarasi package dan folder Java.

## Batas demo
Aplikasi tidak meminta izin internet, tidak terhubung ke WhatsApp atau layanan lain, dan tidak mengirim/menyimpan input. Layar input hanya untuk demonstrasi UI.

## Ikon OBLIVION
Ikon launcher menggunakan gambar logo yang diberikan pengguna, dalam varian PNG mdpi sampai xxxhdpi. Untuk mengganti, timpa file `app/src/main/res/mipmap-*/ic_launcher.png`.
\n## Background\nGambar background yang diberikan pengguna dipasang sebagai latar layar pembuka di `app/src/main/res/drawable-nodpi/oblivion_background.jpg`. Ganti file tersebut untuk menggunakan background lain.\n
## Teks yang mudah diedit
Buka `app/src/main/java/com/oblivion/demo/MainActivity.java`, lalu cari teks di dalam tanda kutip pada `showWelcome()`, `showDemo()`, dan `showDone()`. Ubah teksnya, simpan, lalu Build APK lagi.

## Build APK
Proyek ini belum berisi APK hasil kompilasi. Build memerlukan Android Studio/Android SDK dan Gradle (JDK 17). Di Android Studio: **Open** folder proyek → tunggu Sync → **Build > Build APK(s)**. Hasil debug APK ada di `app/build/outputs/apk/debug/app-debug.apk`.
